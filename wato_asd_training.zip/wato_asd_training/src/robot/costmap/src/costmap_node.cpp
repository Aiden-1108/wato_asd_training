#include <cmath>
#include <memory>
#include <vector>
#include "costmap_node.hpp"

CostmapNode::CostmapNode() : Node("costmap") {
    laser_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
        "/lidar", 10, std::bind(&CostmapNode::laserCallback, this, std::placeholders::_1));

    costmap_pub_ = this->create_publisher<nav_msgs::msg::OccupancyGrid>("/costmap", 10);
}

void CostmapNode::laserCallback(const sensor_msgs::msg::LaserScan::SharedPtr scan) {
    nav_msgs::msg::OccupancyGrid costmap;

    double resolution = 0.1;
    int width = 300;
    int height = 300;

    costmap.header = scan->header; 
    costmap.info.resolution = resolution;
    costmap.info.width = width;
    costmap.info.height = height;
    costmap.info.origin.position.x = -(width * resolution) / 2.0;
    costmap.info.origin.position.y = -(height * resolution) / 2.0;
    costmap.data.assign(width * height, 0);

    std::vector<std::pair<int, int>> obstacles;

    for (size_t i = 0; i < scan->ranges.size(); ++i) {
        double range = scan->ranges[i];
        if (std::isinf(range) || std::isnan(range) || range < scan->range_min || range > scan->range_max) {
            continue;
        }

        // --- REVERTED 180 DEGREE FLIP ---
        // The costmap must use the exact same angle math as the raw Lidar to align visually in Foxglove
        double angle = scan->angle_min + (i * scan->angle_increment);
        
        double x = range * std::cos(angle);
        double y = range * std::sin(angle);

        int grid_x = (x - costmap.info.origin.position.x) / resolution;
        int grid_y = (y - costmap.info.origin.position.y) / resolution;

        if (grid_x >= 0 && grid_x < width && grid_y >= 0 && grid_y < height) {
            obstacles.push_back({grid_x, grid_y});
            costmap.data[grid_y * width + grid_x] = 100; 
        }
    }

    double inscribed_radius = 0.40; 
    double inflation_radius = 0.65; 
    int inflation_cells = inflation_radius / resolution; 

    for (const auto& obs : obstacles) {
        for (int dx = -inflation_cells; dx <= inflation_cells; ++dx) {
            for (int dy = -inflation_cells; dy <= inflation_cells; ++dy) {
                int nx = obs.first + dx;
                int ny = obs.second + dy;

                if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                    double distance = std::sqrt(dx * dx + dy * dy) * resolution;
                    int index = ny * width + nx;

                    if (distance <= inscribed_radius) {
                        costmap.data[index] = 100; 
                    } else if (distance <= inflation_radius) {
                        double decay_factor = 1.0 - ((distance - inscribed_radius) / (inflation_radius - inscribed_radius));
                        int cost = static_cast<int>(99.0 * decay_factor);
                        
                        if (cost > costmap.data[index]) {
                            costmap.data[index] = cost;
                        }
                    }
                }
            }
        }
    }

    costmap_pub_->publish(costmap);
}

int main(int argc, char ** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CostmapNode>());
    rclcpp::shutdown();
    return 0;
}