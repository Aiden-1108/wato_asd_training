#include "control_node.hpp"
#include <cmath>
#include <memory>
#include <chrono>
#include <functional>
#include <algorithm> // Required for std::clamp

ControlNode::ControlNode() : Node("control_node") {
    RCLCPP_INFO(this->get_logger(), "=========================================");
    RCLCPP_INFO(this->get_logger(), " CONTROL NODE IS ONLINE                  ");
    RCLCPP_INFO(this->get_logger(), "=========================================");

    path_sub_ = this->create_subscription<nav_msgs::msg::Path>(
        "/path", 10, std::bind(&ControlNode::pathCallback, this, std::placeholders::_1));
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
        "/odom/filtered", 10, std::bind(&ControlNode::odomCallback, this, std::placeholders::_1));
    
    cmd_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
    
    timer_ = this->create_wall_timer(
        std::chrono::milliseconds(100), std::bind(&ControlNode::controlLoop, this)); 
}

void ControlNode::pathCallback(const nav_msgs::msg::Path::SharedPtr msg) {
    current_path_ = *msg;
    path_received_ = true;
    RCLCPP_INFO(this->get_logger(), "Control Node received a new path!");
}

void ControlNode::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    robot_pose_ = msg->pose.pose;
    odom_received_ = true;
}

double ControlNode::extractYaw(const geometry_msgs::msg::Quaternion& quat) {
    double siny_cosp = 2.0 * (quat.w * quat.z + quat.x * quat.y);
    double cosy_cosp = 1.0 - 2.0 * (quat.y * quat.y + quat.z * quat.z);
    return std::atan2(siny_cosp, cosy_cosp);
}

void ControlNode::controlLoop() {
    geometry_msgs::msg::Twist cmd_msg;

    if (!path_received_ || !odom_received_) {
        return; 
    }

    if (current_path_.poses.empty()) {
        cmd_msg.linear.x = 0.0;
        cmd_msg.angular.z = 0.0;
        cmd_pub_->publish(cmd_msg);
        return;
    }

    double rx = robot_pose_.position.x;
    double ry = robot_pose_.position.y;
    double ryaw = extractYaw(robot_pose_.orientation);

    geometry_msgs::msg::Pose target_pose;
    bool target_found = false;

    for (const auto& pose_stamped : current_path_.poses) {
        double px = pose_stamped.pose.position.x;
        double py = pose_stamped.pose.position.y;
        double dist = std::sqrt(std::pow(px - rx, 2) + std::pow(py - ry, 2));

        if (dist >= lookahead_distance_) {
            target_pose = pose_stamped.pose;
            target_found = true;
            break;
        }
    }

    if (!target_found) {
        target_pose = current_path_.poses.back().pose;
        double final_dist = std::sqrt(std::pow(target_pose.position.x - rx, 2) + std::pow(target_pose.position.y - ry, 2));
        
        if (final_dist < 0.2) {
            RCLCPP_INFO(this->get_logger(), "Arrived at goal! Stopping.");
            cmd_pub_->publish(cmd_msg);
            current_path_.poses.clear();
            return;
        }
    }

    double dx = target_pose.position.x - rx;
    double dy = target_pose.position.y - ry;
    
    double local_x = dx * std::cos(-ryaw) - dy * std::sin(-ryaw);
    double local_y = dx * std::sin(-ryaw) + dy * std::cos(-ryaw);

    double L2 = local_x * local_x + local_y * local_y;
    
    if (L2 > 0.001) {
        double curvature = 2.0 * local_y / L2;
        cmd_msg.linear.x = linear_velocity_; 
        cmd_msg.angular.z = std::clamp(linear_velocity_ * curvature, -1.0, 1.0); 
        
        RCLCPP_INFO(this->get_logger(), "Driving -> Linear: %.2f, Angular: %.2f", cmd_msg.linear.x, cmd_msg.angular.z);
    }

    cmd_pub_->publish(cmd_msg);
}

int main(int argc, char ** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<ControlNode>());
    rclcpp::shutdown();
    return 0;
}