#ifndef CONTROL_NODE_HPP_
#define CONTROL_NODE_HPP_

#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/path.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose.hpp"

class ControlNode : public rclcpp::Node {
public:
    ControlNode();

private:
    void pathCallback(const nav_msgs::msg::Path::SharedPtr msg);
    void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg);
    void controlLoop();
    double extractYaw(const geometry_msgs::msg::Quaternion& quat);

    rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr path_sub_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
    rclcpp::TimerBase::SharedPtr timer_;

    nav_msgs::msg::Path current_path_;
    geometry_msgs::msg::Pose robot_pose_;
    bool path_received_ = false;
    bool odom_received_ = false;

    // Sweet spot: smooth steering, but tight enough to track curves properly
    double lookahead_distance_ = 1.1; 
    double linear_velocity_ = 0.65;   
};

#endif // CONTROL_NODE_HPP_