#include <cmath>
#include "map_memory_node.hpp"

MapMemoryNode::MapMemoryNode() : Node("map_memory"), last_x_(0.0), last_y_(0.0), distance_threshold_(1.5), costmap_updated_(false), should_update_map_(true) {
    costmap_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
        "/costmap", 10, std::bind(&MapMemoryNode::costmapCallback, this, std::placeholders::_1));
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
        "/odom/filtered", 10, std::bind(&MapMemoryNode::odomCallback, this, std::placeholders::_1));
    
    map_pub_ = this->create_publisher<nav_msgs::msg::OccupancyGrid>("/map", 10);
    timer_ = this->create_wall_timer(std::chrono::seconds(1), std::bind(&MapMemoryNode::updateMap, this));

    // Initialize a massive global map (100x100 meters)
    global_map_.info.resolution = 0.1;
    global_map_.info.width = 1000;
    global_map_.info.height = 1000;
    global_map_.info.origin.position.x = -50.0;
    global_map_.info.origin.position.y = -50.0;
    global_map_.data.assign(1000 * 1000, -1); // -1 means unknown space
}

void MapMemoryNode::costmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg) {
    latest_costmap_ = *msg;
    costmap_updated_ = true;
}

void MapMemoryNode::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    robot_odom_ = *msg;
    double x = msg->pose.pose.position.x;
    double y = msg->pose.pose.position.y;

    double distance = std::sqrt(std::pow(x - last_x_, 2) + std::pow(y - last_y_, 2));
    if (distance >= distance_threshold_) {
        last_x_ = x;
        last_y_ = y;
        should_update_map_ = true;
    }
}

double MapMemoryNode::extractYaw(const geometry_msgs::msg::Quaternion& quat) {
    double siny_cosp = 2.0 * (quat.w * quat.z + quat.x * quat.y);
    double cosy_cosp = 1.0 - 2.0 * (quat.y * quat.y + quat.z * quat.z);
    return std::atan2(siny_cosp, cosy_cosp);
}

void MapMemoryNode::integrateCostmap() {
    double robot_x = robot_odom_.pose.pose.position.x;
    double robot_y = robot_odom_.pose.pose.position.y;
    double yaw = extractYaw(robot_odom_.pose.pose.orientation);

    double cos_yaw = std::cos(yaw);
    double sin_yaw = std::sin(yaw);

    for (unsigned int cy = 0; cy < latest_costmap_.info.height; ++cy) {
        for (unsigned int cx = 0; cx < latest_costmap_.info.width; ++cx) {
            int local_cost = latest_costmap_.data[cy * latest_costmap_.info.width + cx];
            if (local_cost == 0) continue; // Skip strictly empty space to save processing

            // Convert local grid index to local physical meters
            double local_x = (cx * latest_costmap_.info.resolution) + latest_costmap_.info.origin.position.x;
            double local_y = (cy * latest_costmap_.info.resolution) + latest_costmap_.info.origin.position.y;

            // Rotate and translate to global physical meters
            double global_x = robot_x + (local_x * cos_yaw - local_y * sin_yaw);
            double global_y = robot_y + (local_x * sin_yaw + local_y * cos_yaw);

            // Convert global physical meters back to global grid index
            int global_cx = (global_x - global_map_.info.origin.position.x) / global_map_.info.resolution;
            int global_cy = (global_y - global_map_.info.origin.position.y) / global_map_.info.resolution;

            if (global_cx >= 0 && global_cx < (int)global_map_.info.width && global_cy >= 0 && global_cy < (int)global_map_.info.height) {
                int global_idx = global_cy * global_map_.info.width + global_cx;
                
                // Overwrite with the highest known cost (lethal obstacles override inflated zones)
                if (local_cost > global_map_.data[global_idx]) {
                    global_map_.data[global_idx] = local_cost;
                }
            }
        }
    }
}

void MapMemoryNode::updateMap() {
    if (should_update_map_ && costmap_updated_) {
        integrateCostmap();
        global_map_.header.stamp = this->now();
        global_map_.header.frame_id = "sim_world"; // Must map to the global coordinate frame
        map_pub_->publish(global_map_);
        should_update_map_ = false;
    }
}

int main(int argc, char ** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<MapMemoryNode>());
    rclcpp::shutdown();
    return 0;
}