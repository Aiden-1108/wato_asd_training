#include "planner_node.hpp"
#include <cmath>
#include <algorithm>

PlannerNode::PlannerNode() : Node("planner_node"), state_(State::WAITING_FOR_GOAL) {
    map_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
        "/map", 10, std::bind(&PlannerNode::mapCallback, this, std::placeholders::_1));
    goal_sub_ = this->create_subscription<geometry_msgs::msg::PointStamped>(
        "/goal_point", 10, std::bind(&PlannerNode::goalCallback, this, std::placeholders::_1));
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
        "/odom/filtered", 10, std::bind(&PlannerNode::odomCallback, this, std::placeholders::_1));
    path_pub_ = this->create_publisher<nav_msgs::msg::Path>("/path", 10);
    timer_ = this->create_wall_timer(
        std::chrono::milliseconds(100), std::bind(&PlannerNode::timerCallback, this));
}

void PlannerNode::mapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg) {
    current_map_ = *msg;
    if (state_ == State::WAITING_FOR_ROBOT_TO_REACH_GOAL) planPath();
}

void PlannerNode::goalCallback(const geometry_msgs::msg::PointStamped::SharedPtr msg) {
    RCLCPP_INFO(this->get_logger(), "--- NEW GOAL RECEIVED: x=%f, y=%f ---", msg->point.x, msg->point.y);
    goal_ = *msg;
    goal_received_ = true;
    state_ = State::WAITING_FOR_ROBOT_TO_REACH_GOAL;
    planPath();
}

void PlannerNode::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    robot_pose_ = msg->pose.pose;
    odom_received_ = true;
}

bool PlannerNode::goalReached() {
    double dx = goal_.point.x - robot_pose_.position.x;
    double dy = goal_.point.y - robot_pose_.position.y;
    return std::sqrt(dx * dx + dy * dy) < 0.5; 
}

void PlannerNode::timerCallback() {
    if (state_ == State::WAITING_FOR_ROBOT_TO_REACH_GOAL) {
        if (goalReached()) {
            RCLCPP_INFO(this->get_logger(), "Goal reached!");
            state_ = State::WAITING_FOR_GOAL;
            goal_received_ = false;
        } else {
            planPath();
        }
    }
}

double PlannerNode::heuristic(CellIndex a, CellIndex b) {
    return std::sqrt(std::pow(a.x - b.x, 2) + std::pow(a.y - b.y, 2));
}

void PlannerNode::planPath() {
    if (!goal_received_ || current_map_.data.empty() || !odom_received_) return;

    double res = current_map_.info.resolution;
    double origin_x = current_map_.info.origin.position.x;
    double origin_y = current_map_.info.origin.position.y;
    int width = current_map_.info.width;
    int height = current_map_.info.height;

    CellIndex start(
        (robot_pose_.position.x - origin_x) / res,
        (robot_pose_.position.y - origin_y) / res
    );
    CellIndex goal_idx(
        (goal_.point.x - origin_x) / res,
        (goal_.point.y - origin_y) / res
    );

    if (start.x < 0 || start.x >= width || start.y < 0 || start.y >= height ||
        goal_idx.x < 0 || goal_idx.x >= width || goal_idx.y < 0 || goal_idx.y >= height) {
        RCLCPP_WARN(this->get_logger(), "Start or goal is out of map bounds.");
        return;
    }

    std::priority_queue<AStarNode, std::vector<AStarNode>, CompareF> open_set;
    std::unordered_map<CellIndex, double, CellIndexHash> g_score;
    std::unordered_map<CellIndex, CellIndex, CellIndexHash> came_from;

    g_score[start] = 0.0;
    open_set.emplace(start, heuristic(start, goal_idx));

    int dx[] = {-1, 0, 1, -1, 1, -1, 0, 1};
    int dy[] = {-1, -1, -1, 0, 0, 1, 1, 1};
    bool found = false;
    int iterations = 0;

    while (!open_set.empty()) {
        iterations++;
        CellIndex current = open_set.top().index;
        open_set.pop();

        if (current == goal_idx) {
            found = true;
            break;
        }

        int current_cost = current_map_.data[current.y * width + current.x];
        if (current_cost < 0) current_cost = 0;

        for (int i = 0; i < 8; ++i) {
            CellIndex neighbor(current.x + dx[i], current.y + dy[i]);

            if (neighbor.x >= 0 && neighbor.x < width && neighbor.y >= 0 && neighbor.y < height) {
                int cost = current_map_.data[neighbor.y * width + neighbor.x];
                
                if (cost < 0) cost = 0; 

                // --- THE ULTIMATE ESCAPE HATCH ---
                if (cost >= 100) {
                    // If we are currently safe, NEVER step into a lethal 100 zone.
                    // If we woke up inside a 100 zone, we are allowed to search through it to find the exit.
                    if (current_cost < 100) continue; 
                } else if (cost > 60) {
                    // Soft trap logic (cells 61-99)
                    if (current_cost <= 60) continue; // Don't walk into high-danger if we are safe
                    if (cost > current_cost) continue; // Only walk towards lower-cost safety
                }

                double move_cost = std::sqrt(dx[i]*dx[i] + dy[i]*dy[i]);
                
                double cost_penalty = 0.0;
                if (cost > 0) {
                    double cost_normalized = static_cast<double>(cost) / 100.0;
                    cost_penalty = std::pow(cost_normalized, 3) * 250.0; 
                }

                double tentative_g = g_score[current] + move_cost + cost_penalty; 

                if (g_score.find(neighbor) == g_score.end() || tentative_g < g_score[neighbor]) {
                    came_from[neighbor] = current;
                    g_score[neighbor] = tentative_g;
                    double f = tentative_g + heuristic(neighbor, goal_idx);
                    open_set.emplace(neighbor, f);
                }
            }
        }
    }

    if (found) {
        RCLCPP_INFO(this->get_logger(), "Path found in %d iterations!", iterations);
        nav_msgs::msg::Path path_msg;
        path_msg.header.stamp = this->now();
        path_msg.header.frame_id = "sim_world";

        CellIndex curr = goal_idx;
        std::vector<geometry_msgs::msg::PoseStamped> poses;

        while (curr != start) {
            geometry_msgs::msg::PoseStamped pose;
            pose.header.stamp = this->now();
            pose.header.frame_id = "sim_world"; 
            
            pose.pose.position.x = (curr.x * res) + origin_x;
            pose.pose.position.y = (curr.y * res) + origin_y;
            pose.pose.position.z = 0.0;
            pose.pose.orientation.w = 1.0; 
            poses.push_back(pose);
            curr = came_from[curr];
        }
        
        std::reverse(poses.begin(), poses.end());
        path_msg.poses = poses;
        path_pub_->publish(path_msg);
    } else {
        RCLCPP_WARN(this->get_logger(), "A* couldn't find a path!");
    }
}

int main(int argc, char ** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PlannerNode>());
    rclcpp::shutdown();
    return 0;
}